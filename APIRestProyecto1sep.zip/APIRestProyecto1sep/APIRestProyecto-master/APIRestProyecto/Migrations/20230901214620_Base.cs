﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace APIRestProyecto.Migrations
{
    /// <inheritdoc />
    public partial class Base : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Stocks",
                columns: table => new
                {
                    StockId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Productoid = table.Column<Guid>(type: "uniqueidentifier", maxLength: 60, nullable: false),
                    CantidadReal = table.Column<int>(type: "int", maxLength: 60, nullable: false),
                    CantidadIdeal = table.Column<int>(type: "int", maxLength: 60, nullable: false),
                    CantidadMinima = table.Column<int>(type: "int", nullable: false),
                    CantidadAlarma = table.Column<int>(type: "int", nullable: false),
                    FechaIngreso = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Stocks", x => x.StockId);
                });

            migrationBuilder.CreateTable(
                name: "Productos",
                columns: table => new
                {
                    Productoid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nombre = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: false),
                    Cantidad = table.Column<int>(type: "int", maxLength: 60, nullable: false),
                    Precio = table.Column<float>(type: "real", nullable: false),
                    Estado = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Lugar = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StockId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Productos", x => x.Productoid);
                    table.ForeignKey(
                        name: "FK_Productos_Stocks_StockId",
                        column: x => x.StockId,
                        principalTable: "Stocks",
                        principalColumn: "StockId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Stocks",
                columns: new[] { "StockId", "CantidadAlarma", "CantidadIdeal", "CantidadMinima", "CantidadReal", "FechaIngreso", "Productoid" },
                values: new object[,]
                {
                    { new Guid("3f1a2a07-1ee7-4f6b-8ef2-7a15903b6e05"), 5, 50, 2, 150, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(24), new Guid("6f4ef8e5-92cb-4763-b98e-562dd09dcb12") },
                    { new Guid("8c663d9a-7d53-45f1-bf63-592ebe144db9"), 5, 100, 30, 250, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(22), new Guid("a5c79f50-4e7e-4db9-b0d5-77a9c0d00ef7") },
                    { new Guid("e8058bc2-9a2a-4ab1-9c0e-90c956d95f56"), 5, 40, 10, 80, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(21), new Guid("fce06e9f-78e4-4d5c-bc89-9e8c1fcfb61d") }
                });

            migrationBuilder.InsertData(
                table: "Productos",
                columns: new[] { "Productoid", "Cantidad", "Estado", "Lugar", "Nombre", "Precio", "StockId" },
                values: new object[,]
                {
                    { new Guid("6f4ef8e5-92cb-4763-b98e-562dd09dcb12"), 1, "Activo", "Estante 2", "Computador Samsung 2018", 2600000f, new Guid("3f1a2a07-1ee7-4f6b-8ef2-7a15903b6e05") },
                    { new Guid("a5c79f50-4e7e-4db9-b0d5-77a9c0d00ef7"), 1, "Activo", "Estante 1", "Audifonos inalambricos", 250000f, new Guid("8c663d9a-7d53-45f1-bf63-592ebe144db9") },
                    { new Guid("fce06e9f-78e4-4d5c-bc89-9e8c1fcfb61d"), 1, "Activo", "Estante 3", "Mouse inalambrico", 50000f, new Guid("e8058bc2-9a2a-4ab1-9c0e-90c956d95f56") }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Productos_StockId",
                table: "Productos",
                column: "StockId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Productos");

            migrationBuilder.DropTable(
                name: "Stocks");
        }
    }
}
