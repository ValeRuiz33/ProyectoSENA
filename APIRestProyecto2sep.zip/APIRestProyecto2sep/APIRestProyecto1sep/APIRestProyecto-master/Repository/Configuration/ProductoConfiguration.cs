﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Repository.Configuration
{
    public class ProductoConfiguration : IEntityTypeConfiguration<Producto>
    {
        public void Configure(EntityTypeBuilder<Producto> builder)
        {
            builder.HasData(
                new Producto
                {
                    PId = new Guid("6f4ef8e5-92cb-4763-b98e-562dd09dcb12"),
                    Nombre = "Computador Samsung 2018",
                    Cantidad =1,
                    Precio = 2600000,
                    Estado = "Activo",
                    Lugar = "Estante 2", 
                    StockId= new Guid("3f1a2a07-1ee7-4f6b-8ef2-7a15903b6e05")
                },
                new Producto
                {
                    PId = new Guid("a5c79f50-4e7e-4db9-b0d5-77a9c0d00ef7"),
                    Nombre = "Audifonos inalambricos",
                    Cantidad = 1,
                    Precio = 250000,
                    Estado = "Activo",
                    Lugar = "Estante 1",
                    StockId =new Guid ("8c663d9a-7d53-45f1-bf63-592ebe144db9")
                },
                new Producto
                {
                    PId = new Guid("a58e77e0-4a53-4e7f-95c7-7c8a3cd2d08d"),
                    Nombre = "Mouse inalambrico",
                    Cantidad = 1,
                    Precio = 50000,
                    Estado = "Activo",
                    Lugar = "Estante 3",
                    StockId = new Guid("e8058bc2-9a2a-4ab1-9c0e-90c956d95f56")
                }
            );
        }
    }
}
