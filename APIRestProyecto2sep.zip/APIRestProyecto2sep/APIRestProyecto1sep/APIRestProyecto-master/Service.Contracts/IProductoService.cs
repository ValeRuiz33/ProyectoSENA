﻿using Shared.DataTransferObjects;

namespace Service.Contracts;

public interface IProductoService
{
    //IEnumerable<ProductoDTO> GetProductos(Guid PId, bool trackChanges);
    //ProductoDTO GetProducto(Guid PId, Guid id, bool trackChanges);
    //ProductoDTO CreateProductoForStock(Guid PId, ProductoForCreationDTO productoForCreation, bool trackChanges);
    //void DeleteProductoForStock(Guid PId, Guid id, bool trackChanges);
    IEnumerable<ProductoDTO> GetAllProductos(bool trackChanges);
    ProductoDTO GetProducto(Guid PId, bool trackChanges);
}
