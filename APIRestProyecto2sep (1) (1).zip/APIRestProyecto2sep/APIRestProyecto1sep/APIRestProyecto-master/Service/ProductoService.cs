﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObjects;

namespace Service
{
    internal sealed class ProductoService : IProductoService
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ProductoService(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }
        public IEnumerable<ProductoDTO> GetAllProductos(bool trackChanges)
        {

            var productos = _repository.Producto.GetAllProductos(trackChanges);

            var productosDTO = productos.Select(e => new ProductoDTO(e.PId, e.Nombre, e.Precio, e.Estado, e.StockId));
            return productosDTO;

        }

        public ProductoDTO GetProducto(Guid PId, bool trackChanges)
        {
            var producto = _repository.Producto.GetProducto(PId, trackChanges);
            //check if the employee is null
            var productoDTO = _mapper.Map<ProductoDTO>(producto);

            return productoDTO;


            //        public IEnumerable<ProductoDTO> GetProductos(Guid PId, bool trackChanges)
            //        {
            //            var stock = _repository.Stock.GetStock(PId, trackChanges);
            //            if (stock is null)
            //                throw new StockNotFoundException(PId);

            //            var productosFromDb = _repository.Producto.GetProductos(PId, trackChanges);
            //            var productosDTO = _mapper.Map<IEnumerable<ProductoDTO>>(productosFromDb);

            //            return productosDTO;
            //        }

            //        public ProductoDTO GetProducto(Guid PId, Guid id, bool trackChanges)
            //        {
            //            var stock = _repository.Stock.GetStock(PId, trackChanges);
            //            if (stock is null)
            //                throw new StockNotFoundException(PId);

            //            var productoDb = _repository.Producto.GetProducto(PId, id, trackChanges);
            //            if (productoDb is null)
            //                throw new ProductoNotFoundException(PId);

            //            var producto = _mapper.Map<ProductoDTO>(productoDb);
            //            return producto;
            //        }

            //        public ProductoDTO CreateProductoForStock(Guid PId, ProductoForCreationDTO productoForCreation, bool trackChanges)
            //        {
            //            var stock = _repository.Stock.GetStock(PId, trackChanges);
            //            if (stock is null)
            //                throw new StockNotFoundException(PId);

            //            var productoEntity = _mapper.Map<Producto>(productoForCreation);

            //            _repository.Producto.CreateProductoForStock(PId, productoEntity);
            //            _repository.Save();

            //            var productoToReturn = _mapper.Map<ProductoDTO>(productoEntity);

            //            return productoToReturn;
            //        }

            //        public void DeleteProductoForStock(Guid PId, Guid id, bool trackChanges)
            //        {
            //            var stock = _repository.Stock.GetStock(PId, trackChanges);
            //            if (stock is null)
            //            {
            //                throw new StockNotFoundException(PId);
            //            }

            //            var productoForStock = _repository.Producto.GetProducto(PId, id, trackChanges);
            //            if (productoForStock is null)
            //            {
            //                throw new ProductoNotFoundException(id);
            //            }

            //            _repository.Producto.DeleteProducto(productoForStock);
            //            _repository.Save();
        }
    }
}