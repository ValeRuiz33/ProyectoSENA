﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities.Models;


namespace Contracts
{
    public interface IProductoRepository
    {
        IEnumerable<Producto> GetAllProductos(bool trackChanges);
        Producto GetProducto(Guid PId, bool trackChanges);
        //Producto GetProducto(Guid PId, Guid id, bool trackChanges);
        //void CreateProductoForStock(Guid ProductoId, Producto producto);
        //void DeleteProducto(Producto producto);
    }
}
