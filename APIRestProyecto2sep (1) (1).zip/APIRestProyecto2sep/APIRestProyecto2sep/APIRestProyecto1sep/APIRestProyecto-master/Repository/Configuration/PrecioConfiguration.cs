﻿using Entities.Models;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Configuration
{
    public class PrecioConfiguration : IEntityTypeConfiguration<Precio>
    {
        public void Configure(EntityTypeBuilder<Precio> builder)
        {
            builder.HasData(
                new Precio
                {
                    PrecioId = new Guid(""),
                    PrecioCompra = 342, 
                    PrecioVenta = 342,
                    PrecioDescuento = 234,
                    FechaDescuento = new DateTime(2023 / 06 / 14),
                    Estado = " ",
                    PId = new Guid("6f4ef8e5-92cb-4763-b98e-562dd09dcb12")

                },
                new Precio
                {
                    PrecioId = new Guid(""),
                    PrecioCompra =34,
                    PrecioVenta = 45,
                    PrecioDescuento = 45,
                    FechaDescuento = new DateTime(2023 / 06 / 14),
                    Estado = "",
                    PId = new Guid("a5c79f50-4e7e-4db9-b0d5-77a9c0d00ef7")
                },
                new Precio
                {
                    PrecioId = new Guid(""),
                    PrecioCompra = 678,
                    PrecioVenta = 456,
                    PrecioDescuento = 456,
                    FechaDescuento = new DateTime(2023 / 06 / 14),
                    Estado = "",
                    PId = new Guid("a58e77e0-4a53-4e7f-95c7-7c8a3cd2d08d")
                }
            );
        }
    }
}
