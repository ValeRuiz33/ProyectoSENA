﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts;
using Shared.DataTransferObjects;
using StockProductos.Presentation.ModelBinders;

namespace StockProductos.Presentation.Controllers
{
    [Route("api/stocks")]
    [ApiController]
    public class StockController : ControllerBase
    {
        private readonly IServiceManager _service;

        public StockController(IServiceManager service) => _service = service;

        [HttpGet]
        public IActionResult GetAllStocks()
        {
            var stocks = _service.StockService.GetAllStocks(trackChanges: false);

            return Ok(stocks);
        }

        [HttpGet("{stockId:guid}", Name = "StockById")]
        public IActionResult GetStockById(Guid stockId)
        {
            var stock = _service.StockService.GetStockById(stockId, trackChanges: false);
            return Ok(stock);
        }

        [HttpGet("collection/({ids})", Name = "StockCollection")]
        public IActionResult GetStockCollection([ModelBinder(BinderType = typeof(ArrayModelBinder))] IEnumerable<Guid> ids)
        {
            var stocks = _service.StockService.GetByIds(ids, trackChanges: false);

            return Ok(stocks);
        }

        [HttpPost]
        public IActionResult CreateStock([FromBody] StockForCreationDTO stock)
        {
            if (stock is null)
                return BadRequest("StockForCreationDto object is null");
            if (!ModelState.IsValid)
                return UnprocessableEntity(ModelState);
            ModelState.ClearValidationState(nameof(StockForCreationDTO));

            var createdStock = _service.StockService.CreateStock(stock);
            return CreatedAtRoute("StockById", new { id = createdStock.stockId }, createdStock);
        }

        [HttpPost("collection")]
        public IActionResult CreateStockCollection([FromBody] IEnumerable<StockForCreationDTO> stockCollection)
        {
            var result = _service.StockService.CreateStockCollection(stockCollection);

            return CreatedAtRoute("StockCollection", new { result.ids }, result.stocks);
        }

        [HttpDelete("{stockId:guid}")]
        public IActionResult DeleteStock(Guid stockId)
        {
            _service.StockService.DeleteStock(stockId, trackChanges: false);
            return NoContent();
        }

        [HttpPut("{stockId:guid}")]
        public IActionResult UpdateStock(Guid stockId, [FromBody] StockForUpdateDTO stock)
        {
            if (stock is null)
                return BadRequest("StockForUpdateDto object is null");
            _service.StockService.UpdateStock(stockId, stock, trackChanges: true);
            return NoContent();
        }
    }
}


      
