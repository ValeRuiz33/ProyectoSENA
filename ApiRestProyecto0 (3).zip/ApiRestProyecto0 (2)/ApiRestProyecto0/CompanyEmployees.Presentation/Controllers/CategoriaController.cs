﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts;
using Shared.DataTransferObjects;
using StockProductos.Presentation.ModelBinders; 


namespace StockProductos.Presentation.Controllers
{
    [Route("api/categorias")]
    [ApiController]
    public class CategoriaController : ControllerBase
    {
        private readonly IServiceManager _service;

        public CategoriaController(IServiceManager service) => _service = service;

        [HttpGet]
        public IActionResult GetAllCategorias()
        {
            var categorias = _service.CategoriaService.GetAllCategorias(trackChanges: false);

            return Ok(categorias);
        }

        [HttpGet("{CategoriaId:guid}", Name = "CategoriaById")]
        public IActionResult GetCategoriaById(Guid CategoriaId)
        {
            var categoria = _service.CategoriaService.GetCategoriaById(CategoriaId, trackChanges: false);
            return Ok(categoria);
        }

        [HttpGet("collection/({ids})", Name = "CategoriaCollection")]
        public IActionResult GetCategoriaCollection([ModelBinder(BinderType = typeof(ArrayModelBinder))] IEnumerable<Guid> ids)
        {
            var categorias = _service.CategoriaService.GetByIds(ids, trackChanges: false);

            return Ok(categorias);
        }

        [HttpPost]
        public IActionResult CreateCategoria([FromBody] CategoriaForCreationDTO categoria)
        {
            if (categoria is null)
                return BadRequest("CategoriaForCreationDTO object is null");
            if (!ModelState.IsValid)
                return UnprocessableEntity(ModelState);
            ModelState.ClearValidationState(nameof(CategoriaForCreationDTO));

            var createdCategoria = _service.CategoriaService.CreateCategoria(categoria);

            return CreatedAtRoute("CategoriaById", new { id = createdCategoria.CategoriaId }, createdCategoria);
        }

        [HttpPost("collection")]
        public IActionResult CreateCategoriaCollection([FromBody] IEnumerable<CategoriaForCreationDTO> categoriaCollection)
        {
            var result = _service.CategoriaService.CreateCategoriaCollection(categoriaCollection);

            return CreatedAtRoute("CategoriaCollection", new { result.ids }, result.categorias);
        }

        [HttpDelete("{CategoriaId:guid}")]
        public IActionResult DeleteCategoria(Guid CategoriaId)
        {
            _service.CategoriaService.DeleteCategoria(CategoriaId, trackChanges: false);
            return NoContent();
        }

        [HttpPut("{CategoriaId:guid}")]
        public IActionResult UpdateCategoria(Guid CategoriaId, [FromBody] CategoriaForUpdateDTO categoria)
        {
            if (categoria is null)
                return BadRequest("CategoriaForUpdateDTO object is null");
            _service.CategoriaService.UpdateCategoria(CategoriaId, categoria, trackChanges: true);
            return NoContent();
        }
    }
}
