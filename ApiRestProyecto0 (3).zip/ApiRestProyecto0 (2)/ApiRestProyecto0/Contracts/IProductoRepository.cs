﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities.Models;


namespace Contracts
{
    public interface IProductoRepository
    {
        //Producto
        //IEnumerable<Producto> GetAllProductoss(bool strackChanges);
        //Producto GetAllProductoss(Guid PId);

        //IEnumerable<Producto> GetProductossById(bool trackChanges);
        //Producto GetProductossById(Guid PId, bool trackChanges);
        void DeleteProducto(Producto producto);

        //stock
        IEnumerable<Producto> GetAllProductos(Guid stockId, bool trackChanges);
        Producto GetProductoById(Guid stockId, Guid PId, bool trackChanges);
        void CreateProductoForStock(Guid stockId, Producto producto);



        //Categoria

        IEnumerable<Producto> GetAllProductosC(Guid categoriaId, bool trackChanges);
        Producto GetProductoByIdC(Guid categoriaId, Guid PId, bool trackChanges);
        void CreateProductoForCategoria(Guid categoriaId, Producto producto);


        //Precio
        Producto GetProductoByIdP(Guid PId, bool trackChanges);
    }
}
