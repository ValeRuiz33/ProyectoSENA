﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Contracts
{
    public interface IPrecioRepository
    {
        //IEnumerable<Precio> GetAllPrecios(Guid PId, bool trackChanges);
        IEnumerable<Precio> GetAllPreciosP(Guid PId, bool trackChanges);
        Precio GetPrecioByIdP(Guid PId, Guid precioId, bool trackChanges);
        void CreatePrecioForProducto(Guid PId, Precio precio, bool trackChanges);
        void DeletePrecio(Precio precio); 


        //Precio GetPrecioById(Guid PrecioId, bool trackChanges);
        //Producto GetProducto(Guid PId, Guid id, bool trackChanges);
        //void CreateProductoForStock(Guid ProductoId, Producto producto);
        //void DeletePrecio(Precio precio);
        //void CreatePrecio(Precio precio);
        //IEnumerable<Precio> GetByIds(IEnumerable<Guid> ids, bool trackChanges);
        //void DeletePrecioForProducto(Precio precio);
    }
}
