﻿using Entities.Models;
using Microsoft.EntityFrameworkCore;
using Repository.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public class RepositoryContext : DbContext
    {

        public RepositoryContext(DbContextOptions options)
        : base(options)
        {
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ProductoConfiguration());
            modelBuilder.ApplyConfiguration(new StockConfiguration());
            modelBuilder.ApplyConfiguration(new CategoriaConfiguration());
            modelBuilder.ApplyConfiguration(new PrecioConfiguration());
            //Para tablitas de rompimiento 
            //modelBuilder.Entity<Producto>()
            //    .HasKey(t => new { t.PId, t.Nombre });
        }

        public DbSet<Stock>? Stocks { get; set; }
        public DbSet<Producto>? Productos { get; set; }
        public DbSet<Precio>? Precios { get; set; }
        public DbSet<Categoria>? Categorias { get; set; }

    }
}