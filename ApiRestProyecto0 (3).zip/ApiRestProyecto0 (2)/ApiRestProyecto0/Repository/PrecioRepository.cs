﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    internal sealed class PrecioRepository : RepositoryBase<Precio>, IPrecioRepository
    {
        public PrecioRepository(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {
        }

        public IEnumerable<Precio> GetAllPrecios(Guid precioId, bool trackChanges) =>
        FindByCondition(e => e.PrecioId.Equals(precioId), trackChanges)
        .OrderBy(e => e.PId)
        .ToList();

        public IEnumerable<Precio> GetAllPreciosP(Guid PId, bool trackChanges) =>
        FindByCondition(e => e.PrecioId.Equals(PId), trackChanges)
        .OrderBy(e => e.PId)
        .ToList();

        public Precio GetPrecioById(Guid precioId, Guid PId, bool trackChanges) =>
            FindByCondition(e => e.PrecioId.Equals(precioId) && e.PId.Equals(PId), trackChanges)
            .SingleOrDefault();
        public Precio GetPrecioByIdP(Guid PId, Guid precioId, bool trackChanges) =>
            FindByCondition(e => e.PId.Equals(PId) && e.PrecioId.Equals(precioId), trackChanges)
            .SingleOrDefault();

        public void CreatePrecioForProducto(Guid precioId, Precio precio, bool trackChanges)
        {
            precio.PrecioId = precioId;
            Create(precio);
        }

        public void DeletePrecio(Precio precio) => Delete(precio);
    }
}

