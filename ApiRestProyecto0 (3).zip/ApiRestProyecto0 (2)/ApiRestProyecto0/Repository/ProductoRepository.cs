﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contracts;
using Entities.Models;
using Microsoft.EntityFrameworkCore;

namespace Repository
{
    internal sealed class ProductoRepository : RepositoryBase<Producto>, IProductoRepository
    {
        public ProductoRepository(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {
        }

        //Producto
        //public IEnumerable<Producto> GetAllProductoss(bool trackChanges) =>
        //    FindAll(trackChanges)
        //    .OrderBy(c => c.Nombre)
        //    .ToList();

        //public Producto GetProductossById(Guid PId, bool trackChanges) =>
        //    FindByCondition(c => c.PId.Equals(PId), trackChanges)
        //    .SingleOrDefault();


        //Stock
        public IEnumerable<Producto> GetAllProductos(Guid stockId, bool trackChanges) =>
            FindByCondition(e => e.StockId.Equals(stockId),trackChanges)
            .OrderBy(e => e.Nombre)
            .ToList();

        public Producto GetProductoById(Guid stockId, Guid PId, bool trackChanges) =>
            FindByCondition(e => e.StockId.Equals(stockId) && e.PId.Equals(PId), trackChanges)
            .SingleOrDefault();
        public Producto GetProductoByIdP(Guid PId, bool trackChanges)=>
             FindByCondition(e => e.PId.Equals(PId), trackChanges)
            .SingleOrDefault();

        public Producto GetProductoByIdP(Guid precioId, Guid PId, bool trackChanges) =>
           FindByCondition(e => e.Precio.Equals(precioId) && e.PId.Equals(PId), trackChanges)
           .SingleOrDefault();

        public void CreateProductoForStock(Guid stockId, Producto producto)
        {
            producto.StockId = stockId;
            Create(producto);
        }
       
        //Categoria
        public IEnumerable<Producto> GetAllProductosC(Guid categoriaId, bool trackChanges) =>
            FindByCondition(e => e.CategoriaId.Equals(categoriaId), trackChanges)
            .OrderBy(e => e.Nombre)
            .ToList();

        public Producto GetProductoByIdC(Guid categoriaId, Guid PId, bool trackChanges) =>
            FindByCondition(e => e.CategoriaId.Equals(categoriaId) && e.PId.Equals(PId), trackChanges)
            .SingleOrDefault();
        public void CreateProductoForCategoria(Guid categoriaId, Producto producto)
        {
            producto.CategoriaId = categoriaId;
            Create(producto);
        }

        public void DeleteProducto(Producto producto) => Delete(producto); 


        //Precio
        //public Producto GetProductoByIdP(Guid PId, bool trackChanges) =>
        //     FindByCondition(e => e.PId.Equals(PId), trackChanges)
        //    .SingleOrDefault();

        //public Producto GetProductoByIdP(Guid precioId, Guid PId, bool trackChanges) =>
        //   FindByCondition(e => e.Precio.Equals(precioId) && e.PId.Equals(PId), trackChanges)
        //   .SingleOrDefault();

    }
}

