﻿using AutoMapper;
using Contracts;
using Service.Contracts;
using Shared.DataTransferObjects;
using Entities.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities.Models;

namespace Service
{
    internal sealed class PrecioService : IPrecioService
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public PrecioService(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }
       
        public IEnumerable<PrecioDTO> GetAllPreciosP(Guid PId, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductoByIdP(PId, trackChanges);
            if (producto is null)
                throw new ProductoNotFoundException(PId);

            var preciosFromDb = _repository.Precio.GetAllPreciosP(PId, trackChanges);
            var preciosDTO = _mapper.Map<IEnumerable<PrecioDTO>>(preciosFromDb);

            return preciosDTO;
        }

        public PrecioDTO GetPrecioByIdP(Guid PId, Guid precioId, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductoByIdP(PId, trackChanges);
            if (producto is null)
                throw new ProductoNotFoundException(PId);

            var precioDb = _repository.Precio.GetPrecioByIdP(PId, precioId, trackChanges);
            if (precioDb is null)
                throw new PrecioNotFoundException(precioId);

            var precio = _mapper.Map<PrecioDTO>(precioDb);
            return precio;
        }

        public PrecioDTO CreatePrecioForProducto(Guid PId, PrecioForCreationDTO precioForCreation, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductoByIdP(PId, trackChanges);
            if (producto is null)
                throw new ProductoNotFoundException(PId);

            var precioEntity = _mapper.Map<Precio>(precioForCreation);

            _repository.Precio.CreatePrecioForProducto(PId, precioEntity, trackChanges);
            _repository.Save();

            var precioToReturn = _mapper.Map<PrecioDTO>(precioEntity);

            return precioToReturn;
        }
        

        public void DeletePrecioForProducto(Guid PId, Guid precioId, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductoByIdP(PId, trackChanges);
            if (producto is null)
                throw new ProductoNotFoundException(PId);

            var precioForProducto = _repository.Precio.GetPrecioByIdP(PId, precioId, trackChanges);
            if (precioForProducto is null)
                throw new PrecioNotFoundException(precioId);

            _repository.Precio.DeletePrecio(precioForProducto);
            _repository.Save();
        }

        public void UpdatePrecioForProducto(Guid PId, Guid precioId, PrecioForUpdateDTO precioForUpdate,
        bool compTrackChanges, bool empTrackChanges)
        {
            var producto = _repository.Producto.GetProductoByIdP(PId, compTrackChanges);
            if (producto is null)
                throw new ProductoNotFoundException(PId);

            var precioEntity = _repository.Precio.GetPrecioByIdP(PId, precioId, empTrackChanges);
            if (precioEntity is null)
                throw new PrecioNotFoundException(precioId);

            _mapper.Map(precioForUpdate, precioEntity);
            _repository.Save();
        }

        //public (EmployeeForUpdateDto employeeToPatch, Employee employeeEntity) GetEmployeeForPatch(Guid companyId, Guid id, bool compTrackChanges, bool empTrackChanges)
        //{
        //    var company = _repository.Company.GetCompany(companyId, compTrackChanges);
        //    if (company is null)
        //        throw new CompanyNotFoundException(companyId);
        //    var employeeEntity = _repository.Employee.GetEmployee(companyId, id, empTrackChanges);
        //    if (employeeEntity is null)
        //        throw new EmployeeNotFoundException(companyId);
        //    var employeeToPatch = _mapper.Map<EmployeeForUpdateDto>(employeeEntity);
        //    return (employeeToPatch, employeeEntity);
        //}

        //public void SaveChangesForPatch(EmployeeForUpdateDto employeeToPatch, Employee employeeEntity)
        //{
        //    _mapper.Map(employeeToPatch, employeeEntity);
        //    _repository.Save();
        //}   
    }
}

