﻿using Shared.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts
{
    public interface ICategoriaService
    {
        IEnumerable<CategoriaDTO> GetAllCategorias(bool trackChanges);
        CategoriaDTO GetCategoriaById(Guid CategoriaId, bool trackChanges);
        CategoriaDTO CreateCategoria(CategoriaForCreationDTO categoria);
        IEnumerable<CategoriaDTO> GetByIds(IEnumerable<Guid> ids, bool trackChanges);
        (IEnumerable<CategoriaDTO> categorias, string ids) CreateCategoriaCollection
                (IEnumerable<CategoriaForCreationDTO> categoriaCollection);
        void DeleteCategoria(Guid CategoriaId, bool trackChanges);
        void UpdateCategoria(Guid CategoriaId, CategoriaForUpdateDTO categoriaForUpdate, bool trackChanges);
    }
}

