﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.DataTransferObjects
{
    public record PrecioForUpdateDTO(float PrecioCompra, float PrecioVenta, float PrecioDescuento, DateTime FechaDescuento, string Estado,
        IEnumerable<ProductoForCreationDTO> Producto);
}


