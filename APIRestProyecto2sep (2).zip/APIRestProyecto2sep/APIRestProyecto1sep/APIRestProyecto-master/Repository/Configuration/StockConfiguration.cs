﻿using Entities.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Repository.Configuration
{
    public class StockConfiguration : IEntityTypeConfiguration<Stock>
    {
        public void Configure(EntityTypeBuilder<Stock> builder)
        {
            builder.HasData(
                new Stock
                {
                    stockId = new Guid("3f1a2a07-1ee7-4f6b-8ef2-7a15903b6e05"),
                    CantidadReal = 150,
                    CantidadIdeal = 50,
                    CantidadMinima = 2,
                    CantidadAlarma = 5,
                    FechaIngreso = new DateTime (2023/06/14),
                    Productoid = new Guid("6f4ef8e5-92cb-4763-b98e-562dd09dcb12")
                },
                new Stock
                {
                    stockId = new Guid("8c663d9a-7d53-45f1-bf63-592ebe144db9"),
                    CantidadReal = 250,
                    CantidadIdeal = 100,
                    CantidadMinima = 30,
                    CantidadAlarma = 5,
                    FechaIngreso = new DateTime (2023/06/15),
                    Productoid = new Guid("a5c79f50-4e7e-4db9-b0d5-77a9c0d00ef7")
                },
                new Stock
                {
                    stockId = new Guid("e8058bc2-9a2a-4ab1-9c0e-90c956d95f56"),
                    CantidadReal = 80,
                    CantidadIdeal = 40,
                    CantidadMinima = 10,
                    CantidadAlarma = 5,
                    FechaIngreso = new DateTime (2023/06/16),
                    Productoid = new Guid("a58e77e0-4a53-4e7f-95c7-7c8a3cd2d08d")
                }
            );
        }
    }
}
