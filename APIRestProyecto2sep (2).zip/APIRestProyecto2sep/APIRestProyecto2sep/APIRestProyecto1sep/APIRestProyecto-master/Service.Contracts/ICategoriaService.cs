﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts
{
    public interface ICategoriaService
    {
        //IEnumerable<ProductoDTO> GetProductos(Guid PId, bool trackChanges);
        //ProductoDTO GetProducto(Guid PId, Guid id, bool trackChanges);
        //ProductoDTO CreateProductoForStock(Guid PId, ProductoForCreationDTO productoForCreation, bool trackChanges);
        //void DeleteProductoForStock(Guid PId, Guid id, bool trackChanges);
        IEnumerable<CategoriaDTO> GetAllCategorias(bool trackChanges);
        CategoriaDTO GetCategoria(Guid CategoriaId, bool trackChanges);
    }
}
