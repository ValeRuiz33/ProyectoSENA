﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shared.DataTransferObjects
{
    public record CategoriaDTO(Guid PId, string Nombre, float Precio, string Estado, Guid StockId);
}
