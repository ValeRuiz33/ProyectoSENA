﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts
{
    public interface ICategoriaRepository
    {
        IEnumerable<Categoria> GetAllCategorias(bool trackChanges);
        Categoria GetCategoria(Guid CategoriaId, bool trackChanges);
    }
}
