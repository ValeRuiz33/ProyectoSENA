﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts
{
    public interface IPrecioRepository
    {
        IEnumerable<Precio> GetAllPrecios(bool trackChanges);
        Precio GetPrecio(Guid PrecioId, bool trackChanges);
    }
}
