﻿using AutoMapper;
using Contracts;
using Service.Contracts;

namespace Service
{
    public sealed class ServiceManager : IServiceManager
    {
        private readonly Lazy<IProductoService> _productoService;
        private readonly Lazy<IStockService> _stockService;
        private readonly Lazy<IPrecioService> _precioService;
        private readonly Lazy<ICategoriaService> _categoriaService;

        public ServiceManager(IRepositoryManager repositoryManager, ILoggerManager logger, IMapper mapper)
        {
            _productoService = new Lazy<IProductoService>(() => new ProductoService(repositoryManager, logger, mapper));
            _stockService = new Lazy<IStockService>(() => new StockService(repositoryManager, logger, mapper));
            _precioService = new Lazy<IPrecioService>(() => new PrecioService(repositoryManager, logger, mapper));
            _categoriaService = new Lazy<ICategoriaService>(() => new CategoriaService(repositoryManager, logger, mapper));
        }

        public IProductoService ProductoService => _productoService.Value;

        public IStockService StockService => _stockService.Value;

        public IPrecioService PrecioService => _precioService.Value;

        public ICategoriaService CategoriaService => _categoriaService.Value;
    }
}
