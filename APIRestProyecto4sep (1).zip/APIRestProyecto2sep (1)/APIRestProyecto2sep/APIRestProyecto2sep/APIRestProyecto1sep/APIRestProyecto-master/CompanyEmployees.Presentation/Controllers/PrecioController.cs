﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockProductos.Presentation.Controllers
{
    //[Route("api/stocks/{stockId}/productos")]
    //[ApiController]
    //public class ProductoController : ControllerBase
    //{
    //    private readonly IServiceManager _service;

    //    //public ProductoController(IServiceManager service)
    //    //{
    //    //    _service = service ?? throw new ArgumentNullException(nameof(service));
    //    //}

    //    public ProductoController(IServiceManager service) => _service = service;

    //    [HttpGet]
    //    public IActionResult GetProductosForStock(Guid stockId)
    //    {
    //        var productos = _service.ProductoService.GetProductos(stockId, trackChanges: false);
    //        return Ok(productos);
    //    }

    //    [HttpGet("{id:guid}", Name = "GetProductoForStock")]
    //    public IActionResult GetProductoForStock(Guid stockId, Guid id)
    //    {
    //        var producto = _service.ProductoService.GetProducto(stockId, id, trackChanges: false);
    //        return Ok(producto);
    //    }

    //    [HttpPost]
    //    public IActionResult CreateProductoForStock(Guid stockId, [FromBody] ProductoForCreationDTO producto)
    //    {
    //        if (producto is null)
    //            return BadRequest("ProductoForCreationDTO object is null");

    //        var productoToReturn = _service.ProductoService.CreateProductoForStock(stockId, producto, trackChanges: false);

    //        return CreatedAtRoute("GetProductoForStock", new { stockId, id = productoToReturn.PId },
    //            productoToReturn);
    //    }

    //    [HttpDelete("{id:guid}")]
    //    public IActionResult DeleteProductoForStock(Guid stockId, Guid id)
    //    {
    //        _service.ProductoService.DeleteProductoForStock(stockId, id, trackChanges: false);
    //        return NoContent();
    //    }

    [ApiController]
    [Route("api/precio")]
    public class PrecioController : ControllerBase
    {
        private readonly IServiceManager _service;

        public PrecioController(IServiceManager service) =>
            _service = service;

        [HttpGet]
        public IActionResult GetPrecios()
        {
            //throw new Exception("Exception");
            var precios =
            _service.PrecioService.GetAllPrecios(trackChanges: false);
            return Ok(precios);

        }
        [HttpGet("{id:guid}")]
        public IActionResult GetPrecio(Guid PrecioId)
        {
            var precio = _service.PrecioService.GetPrecio(PrecioId, trackChanges: false);
            return Ok(precio);
        }
    }
}
