﻿using Contracts;
using Entities.Models;

namespace Repository
{
    internal sealed class PrecioRepository : RepositoryBase<Precio>, IPrecioRepository
    {
        public PrecioRepository(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {
        }

        public IEnumerable<Precio> GetAllPrecios(bool trackChanges) =>
            FindAll(trackChanges)
            .OrderBy(e => e.PrecioCompra)
            .ToList();

        public Precio GetPrecio(Guid preciosId, bool trackChanges) =>
            FindByCondition(e => e.PrecioId.Equals(preciosId), trackChanges)
            .SingleOrDefault();

        //public void CreateProductoForStock(Guid stockId, Producto producto)
        //{
        //    producto.StockId = stockId;
        //    Create(producto);
        //}

        //public void DeleteProducto(Producto producto) => Delete(producto);
    }
}

