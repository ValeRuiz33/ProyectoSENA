﻿ using Entities.Models;
using Shared.DataTransferObjects;
using AutoMapper;

namespace APIRestProyecto
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Stock, StockDTO>()
            .ForCtorParam("CantidadIdeal",
            //.ForMember(c => c.CantidadIdeal,
            opt => opt.MapFrom(x => string.Join(' ', x.Productoid, x.CantidadReal)));
            

            CreateMap<Producto, ProductoDTO>();
            CreateMap<Stock, StockDTO>();

            //CreateMap<StockForCreationDTO, Stock>();

            //CreateMap<ProductoForCreationDTO, Producto>();
        }
    }
}
