﻿using AutoMapper;
using Contracts;
using Service.Contracts;
using Shared.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    internal sealed class CategoriaService : ICategoriaService
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public CategoriaService(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }
        public IEnumerable<CategoriaDTO> GetAllCategoriasos(bool trackChanges)
        {

            var categorias = _repository.Categoria.GetAllCategorias(trackChanges);

            var categoriasDTO = categorias.Select(e => new CategoriaDTO(e.PId, e.Nombre, e.Precio, e.Estado, e.StockId));
            return categoriasDTO;

        }

        public CategoriaDTO GetProducto(Guid CategoriaId, bool trackChanges)
        {
            var categoria = _repository.Categoria.GetCategoria(CategoriaId, trackChanges);
            //check if the employee is null
            var categoriaDTO = _mapper.Map<CategoriaDTO>(categoria);

            return categoriaDTO;


            //        public IEnumerable<ProductoDTO> GetProductos(Guid PId, bool trackChanges)
            //        {
            //            var stock = _repository.Stock.GetStock(PId, trackChanges);
            //            if (stock is null)
            //                throw new StockNotFoundException(PId);

            //            var productosFromDb = _repository.Producto.GetProductos(PId, trackChanges);
            //            var productosDTO = _mapper.Map<IEnumerable<ProductoDTO>>(productosFromDb);

            //            return productosDTO;
            //        }

            //        public ProductoDTO GetProducto(Guid PId, Guid id, bool trackChanges)
            //        {
            //            var stock = _repository.Stock.GetStock(PId, trackChanges);
            //            if (stock is null)
            //                throw new StockNotFoundException(PId);

            //            var productoDb = _repository.Producto.GetProducto(PId, id, trackChanges);
            //            if (productoDb is null)
            //                throw new ProductoNotFoundException(PId);

            //            var producto = _mapper.Map<ProductoDTO>(productoDb);
            //            return producto;
            //        }

            //        public ProductoDTO CreateProductoForStock(Guid PId, ProductoForCreationDTO productoForCreation, bool trackChanges)
            //        {
            //            var stock = _repository.Stock.GetStock(PId, trackChanges);
            //            if (stock is null)
            //                throw new StockNotFoundException(PId);

            //            var productoEntity = _mapper.Map<Producto>(productoForCreation);

            //            _repository.Producto.CreateProductoForStock(PId, productoEntity);
            //            _repository.Save();

            //            var productoToReturn = _mapper.Map<ProductoDTO>(productoEntity);

            //            return productoToReturn;
            //        }

            //        public void DeleteProductoForStock(Guid PId, Guid id, bool trackChanges)
            //        {
            //            var stock = _repository.Stock.GetStock(PId, trackChanges);
            //            if (stock is null)
            //            {
            //                throw new StockNotFoundException(PId);
            //            }

            //            var productoForStock = _repository.Producto.GetProducto(PId, id, trackChanges);
            //            if (productoForStock is null)
            //            {
            //                throw new ProductoNotFoundException(id);
            //            }

            //            _repository.Producto.DeleteProducto(productoForStock);
            //            _repository.Save();
        }
    }
}
