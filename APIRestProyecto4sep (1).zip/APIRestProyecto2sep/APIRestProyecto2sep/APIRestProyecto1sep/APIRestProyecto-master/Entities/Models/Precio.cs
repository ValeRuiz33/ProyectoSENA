﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{
    public class Precio
    {
        [Column("PrecioId")]
        [Key]
        public Guid PrecioId { get; set; }
        [Required(ErrorMessage = "Company name is a required field.")]
        [MaxLength(60, ErrorMessage = "Maximum length for the Name is 60 characters.")]
        public float? PrecioCompra { get; set; }
        [Required(ErrorMessage = "Company address is a required field.")]
        [MaxLength(60, ErrorMessage = "Maximum length for the Address is 60 characters")]
        public float PrecioVenta { get; set; }
        public float PrecioDescuento { get; set; }
        public DateTime FechaDescuento { get; set; }
        public string Estado { get; set; }
        public Guid PId { get; set; }
        public Producto? Producto { get; set; }
    }
}
