﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    internal sealed class PrecioRepository : RepositoryBase<Precio>, IPreciosRepository
    {
        public PrecioRepository(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {
        }

        public IEnumerable<Precio> GetAllPrecios(bool trackChanges) =>
            FindAll(trackChanges)
            .OrderBy(e => e.PrecioCompra)
            .ToList();

        public Precio GetPrecio(Guid preciosId, bool trackChanges) =>
            FindByCondition(e => e.PId.Equals(preciosId), trackChanges)
            .SingleOrDefault();

        //public void CreateProductoForStock(Guid stockId, Producto producto)
        //{
        //    producto.StockId = stockId;
        //    Create(producto);
        //}

        //public void DeleteProducto(Producto producto) => Delete(producto);
    }
}

