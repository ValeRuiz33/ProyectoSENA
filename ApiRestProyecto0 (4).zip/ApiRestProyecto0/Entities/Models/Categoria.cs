﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Models
{
    public class Categoria
    {
        [Column("categoriaId")]
        [Key]
        public Guid categoriaId { get; set; }
        [Required(ErrorMessage = "Categoria name is a required field.")]
        [MaxLength(60, ErrorMessage = "Maximum length for the Name is 60 characters.")]
        public string Nombre { get; set; }
        [Required(ErrorMessage = "Categoria address is a required field.")]
        [MaxLength(60, ErrorMessage = "Maximum length for the Address is 60 characters")]
        public ICollection<Producto>? Productos { get; set; }

    }
}
