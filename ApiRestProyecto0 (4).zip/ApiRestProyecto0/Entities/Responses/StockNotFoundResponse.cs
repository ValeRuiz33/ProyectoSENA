﻿namespace Entities.Responses;

public sealed class StockNotFoundResponse : ApiNotFoundResponse
{
    public StockNotFoundResponse(Guid stockId)
        : base($"Stock with id: {stockId} is not found in db.")
    {
    }
}
