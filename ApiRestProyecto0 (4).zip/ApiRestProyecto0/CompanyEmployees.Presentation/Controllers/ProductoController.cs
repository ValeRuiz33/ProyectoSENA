﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts;
using Shared.DataTransferObjects;
using StockProductos.Presentation.ModelBinders;

namespace StockProductos.Presentation.Controllers
{
    [Route("api/stocks/{stockId}/productos")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        private readonly IServiceManager _service;
        public ProductoController(IServiceManager service) => _service = service;

        //Stocks

        [HttpGet]
        //[Route("api/stocks/{stockId}/productos")]
        public IActionResult GetProductosForStock(Guid stockId)
        {
            var productos = _service.ProductoService.GetAllProductos(stockId, trackChanges: false);
            return Ok(productos);
        }//


        [HttpGet("{id:guid}", Name = "GetProductoForStock")]
        public IActionResult GetProductoForStock(Guid stockId, Guid PId)
        {
            var productos = _service.ProductoService.GetProductoById(stockId, PId, trackChanges: false);
            return Ok(productos);
        }

        [HttpPost]
        public IActionResult CreateProductoForStock(Guid stockId, [FromBody] ProductoForCreationDTO producto)
        {
            if (producto is null)
            {
                return BadRequest("ProductForCreationDTO object is null");
            }
            var productoToReturn = _service.ProductoService.CreateProductoForStock(stockId, producto, trackChanges: false);

            return CreatedAtRoute("GetProductForStock", new { stockId, id = productoToReturn.PId },
                productoToReturn);
        }
        //
        [HttpDelete("{id:guid}")]
        public IActionResult DeleteProductoForStock(Guid stockId, Guid PId)
        {
            _service.ProductoService.DeleteProductoForStock(stockId, PId, trackChanges: false);
            return NoContent();
        }
        //
        [HttpPut("{id:guid}")]
        public IActionResult UpdateProductoForStock(Guid stockId, Guid PId, [FromBody] ProductoForUpdateDTO producto)
        {
            if (producto is null)
            {
                return BadRequest("ProductoForUpdateDTO object is null");
            }

            _service.ProductoService.UpdateProductoForStock(stockId, PId, producto, compTrackChanges: false, empTrackChanges: true);
            return NoContent();
        }
        /// CATEGORIA

        [HttpGet]
        [Route("/api/categorias/{categoriaId}/productos")]
        public IActionResult GetProductosForCategoria(Guid categoriaId)
        {
            var productos = _service.ProductoService.GetAllProductosC(categoriaId, trackChanges: false);
            return Ok(productos);
        }//


        [HttpGet("{categoriaId:guid}", Name = "GetProductoForCategoria")]
        public IActionResult GetProductoForCategoria(Guid categoriaId, Guid PId)
        {
            var productos = _service.ProductoService.GetProductoByIdC(categoriaId, PId, trackChanges: false);
            return Ok(productos);
        }

        [HttpPost]
        public IActionResult CreateProductoForCategoria(Guid categoriaId, [FromBody] ProductoForCreationDTO producto)
        {
            if (producto is null)
            {
                return BadRequest("ProductForCreationDTO object is null");
            }
            var productoToReturn = _service.ProductoService.CreateProductoForCategoria(categoriaId, producto, trackChanges: false);

            return CreatedAtRoute("GetProductForCategoria", new { categoriaId, id = productoToReturn.PId },
                productoToReturn);
        }
        //
        [HttpDelete("{id:guid}")]
        public IActionResult DeleteProductoForCategoria(Guid categoriaId, Guid PId)
        {
            _service.ProductoService.DeleteProductoForCategoria(categoriaId, PId, trackChanges: false);
            return NoContent();
        }
        //
        [HttpPut("{id:guid}")]
        public IActionResult UpdateProductoForCategoria(Guid categoriaId, Guid PId, [FromBody] ProductoForUpdateDTO producto)
        {
            if (producto is null)
            {
                return BadRequest("ProductoForUpdateDTO object is null");
            }

            _service.ProductoService.UpdateProductoForCategoria(categoriaId, PId, producto, compTrackChanges: false, empTrackChanges: true);
            return NoContent();
        }
        //Producto

        [HttpGet("/api/productos")]
        public IActionResult GetAllProducts()
        {
            var productos = _service.ProductoService.GetAllProducts(trackChanges: false);
            return Ok(productos);
        }

        [HttpGet("/api/productos/{PId:guid}", Name = "ProductById")]
        public IActionResult GetProductById(Guid PId)
        {
            var producto = _service.ProductoService.GetProductById(PId, trackChanges: false);
            return Ok(producto);
        }

        [HttpGet("collection/({ids})", Name = "ProductoCollection")]
        public IActionResult GetProductoCollection([ModelBinder(BinderType = typeof(ArrayModelBinder))] IEnumerable<Guid> ids)
        {
            var productos = _service.ProductoService.GetByIds(ids, trackChanges: false);

            return Ok(productos);
        }

        [HttpPost]
        public IActionResult CreateProducto([FromBody] ProductoForCreationDTO producto)
        {
            if (producto is null)
                return BadRequest("ProductoForCreationDTO object is null");
            if (!ModelState.IsValid)
                return UnprocessableEntity(ModelState);
            ModelState.ClearValidationState(nameof(ProductoForCreationDTO));

            var createdProducto = _service.ProductoService.CreateProduct(producto);
            return CreatedAtRoute("ProductById", new { PId = createdProducto.PId }, createdProducto);
        }

        [HttpPost("collection")]
        public IActionResult CreateProductoCollection([FromBody] IEnumerable<ProductoForCreationDTO> productoCollection)
        {
            var result = _service.ProductoService.CreateProductoCollection(productoCollection);

            return CreatedAtRoute("ProductoCollection", new { result.ids }, result.productos);
        }

        [HttpDelete("/api/productos/{PId:guid}")]
        public IActionResult DeleteProducto(Guid PId)
        {
            _service.ProductoService.DeleteProducto(PId, trackChanges: false);
            return NoContent();
        }

        [HttpPut("/api/productos/{PId:guid}")]
        public IActionResult UpdateProducto(Guid PId, [FromBody] ProductoForUpdateDTO producto)
        {
            if (producto is null)
                return BadRequest("ProductoForUpdateDTO object is null");
            _service.ProductoService.UpdateProducto(PId, producto, trackChanges: true);
            return NoContent();
        }
    }
}

