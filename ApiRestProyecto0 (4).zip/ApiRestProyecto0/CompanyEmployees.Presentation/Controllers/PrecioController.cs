﻿using Microsoft.AspNetCore.Mvc;
using Service.Contracts;
using Shared.DataTransferObjects;
using StockProductos.Presentation.ModelBinders;

namespace StockProductos.Presentation.Controllers
{
    [Route("api/productos/{PId}/precios")]
    [ApiController]
    public class PrecioController : ControllerBase
    {
        private readonly IServiceManager _service;

        public PrecioController(IServiceManager service) => _service = service;

        [HttpGet]
        public IActionResult GetPreciosForProducto(Guid PId)
        {
            var precios = _service.PrecioService.GetAllPrecios(PId, trackChanges: false);
            return Ok(precios);
        }

        [HttpGet("{PrecioId:guid}", Name = "GetPrecioForProducto")]
        public IActionResult GetPrecioForProducto(Guid PId, Guid precioId)
        {
            var precio = _service.PrecioService.GetPrecioById(PId, precioId, trackChanges: false);
            return Ok(precio);
        }

        [HttpPost]
        public IActionResult CreatePrecioForProducto(Guid PId, [FromBody] PrecioForCreationDTO precio)
        {
            if (precio is null)
                return BadRequest("PrecioForCreationDTO object is null");

            var precioToReturn = _service.PrecioService.CreatePrecioForProducto(PId, precio, trackChanges: false);

            return CreatedAtRoute("GetPrecioForProducto", new { PId, id = precioToReturn.PrecioId },
                precioToReturn);
        }

        [HttpDelete("{id:guid}")]
        public IActionResult DeletePrecioForProducto(Guid PId, Guid id)
        {
            _service.PrecioService.DeletePrecioForProducto(PId, id, trackChanges: false);

            return NoContent();
        }

        [HttpPut("{id:guid}")]
        public IActionResult UpdatePrecioForProducto(Guid PId, Guid id,
        [FromBody] PrecioForUpdateDTO precio)
        {
            if (precio is null)
                return BadRequest("PrecioForUpdateDTO object is null");

            _service.PrecioService.UpdatePrecioForProducto(PId, id, precio,
                compTrackChanges: false, empTrackChanges: true);

            return NoContent();
        }


        //[HttpPatch("{id:guid}")]
        //public IActionResult PartiallyUpdateEmployeeForCompany
        //    (Guid companyId, Guid id, [FromBody] JsonPatchDocument<EmployeeForUpdateDto> patchDoc)
        //{
        //    if (patchDoc is null)
        //        return BadRequest("patchDoc object sent from client is null.");

        //    var result = _service.EmployeeService.GetEmployeeForPatch(companyId, id, compTrackChanges: false, empTrackChanges: true);

        //    patchDoc.ApplyTo(result.employeeToPatch);

        //    _service.EmployeeService.SaveChangesForPatch(result.employeeToPatch, result.employeeEntity);
        //    return NoContent();
        //}
    }
}
