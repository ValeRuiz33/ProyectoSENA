﻿using Shared.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Contracts
{
    public interface IPrecioService
    {      
        IEnumerable<PrecioDTO> GetAllPrecios(Guid PId, bool trackChanges);
        PrecioDTO GetPrecioById(Guid PId, Guid PrecioId, bool trackChanges);
        PrecioDTO CreatePrecioForProducto(Guid PId, PrecioForCreationDTO precioForCreation, bool trackChanges);
        void DeletePrecioForProducto(Guid PId, Guid PrecioId, bool trackChanges);
        void UpdatePrecioForProducto(Guid PId, Guid PrecioId, PrecioForUpdateDTO precioForUpdate, bool compTrackChanges, bool empTrackChanges);
    }

}

