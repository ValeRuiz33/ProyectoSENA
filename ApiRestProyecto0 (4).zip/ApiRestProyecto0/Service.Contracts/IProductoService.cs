﻿using Shared.DataTransferObjects;
namespace Service.Contracts;

public interface IProductoService
{
    //Productos
    IEnumerable<ProductoDTO> GetAllProducts(bool trackChanges);
    ProductoDTO GetProductById(Guid PId, bool trackChanges);
    ProductoDTO CreateProduct(ProductoForCreationDTO producto);
    IEnumerable<ProductoDTO> GetByIds(IEnumerable<Guid> ids, bool trackChanges);
    (IEnumerable<ProductoDTO> productos, string ids) CreateProductoCollection
            (IEnumerable<ProductoForCreationDTO> productoCollection);
    void DeleteProducto(Guid PId, bool trackChanges);
    void UpdateProducto(Guid PId, ProductoForUpdateDTO productoForUpdate, bool trackChanges);

    //Stock
    IEnumerable<ProductoDTO> GetAllProductos(Guid stockId, bool trackChanges);
    ProductoDTO GetProductoById(Guid stockId, Guid PId, bool trackChanges);
    ProductoDTO CreateProductoForStock(Guid stockId, ProductoForCreationDTO productoForCreation, bool trackChanges);
    void DeleteProductoForStock(Guid stockId, Guid PId, bool trackChanges);
    void UpdateProductoForStock(Guid stockId, Guid PId, ProductoForUpdateDTO productoForUpdate, bool compTrackChanges, bool empTrackChanges);

    //Categoria
    IEnumerable<ProductoDTO> GetAllProductosC(Guid categoriaId, bool trackChanges);
    ProductoDTO GetProductoByIdC(Guid categoriaId, Guid PId, bool trackChanges);
    ProductoDTO CreateProductoForCategoria(Guid categoriaId, ProductoForCreationDTO productoForCreation, bool trackChanges);
    void DeleteProductoForCategoria(Guid categoriaId, Guid PId, bool trackChanges);
    void UpdateProductoForCategoria(Guid categoriaId, Guid PId, ProductoForUpdateDTO productoForUpdate, bool compTrackChanges, bool empTrackChanges);
}
