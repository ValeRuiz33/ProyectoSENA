﻿using Shared.DataTransferObjects;

namespace Service.Contracts;

public interface IStockService
{
    IEnumerable<StockDTO> GetAllStocks(bool trackChanges);
    StockDTO GetStockById(Guid stockId, bool trackChanges);
    StockDTO CreateStock(StockForCreationDTO stock);
    IEnumerable<StockDTO> GetByIds(IEnumerable<Guid> ids, bool trackChanges);
    (IEnumerable<StockDTO> stocks, string ids) CreateStockCollection
            (IEnumerable<StockForCreationDTO> stockCollection);
    void DeleteStock(Guid stockId, bool trackChanges);
    void UpdateStock(Guid stockId, StockForUpdateDTO stockForUpdate, bool trackChanges);
}

