﻿using Contracts;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    internal sealed class PrecioRepository : RepositoryBase<Precio>, IPrecioRepository
    {
        public PrecioRepository(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {
        }

        public IEnumerable<Precio> GetAllPrecios(Guid PId, bool trackChanges) =>
           FindByCondition(e => e.PId.Equals(PId), trackChanges)
           .OrderBy(e => e.PrecioVenta)
           .ToList();

        public Precio GetPrecioById(Guid PId, Guid PrecioId, bool trackChanges) =>
            FindByCondition(e => e.PId.Equals(PId) && e.PrecioId.Equals(PrecioId), trackChanges)
            .SingleOrDefault();

        public void CreatePrecioForProducto(Guid PId, Precio precio)
        {
            precio.PId = PId;
            Create(precio);
        }
        public void DeletePrecio(Precio precio) => Delete(precio);


    }
}

