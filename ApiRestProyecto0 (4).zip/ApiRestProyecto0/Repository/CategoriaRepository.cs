﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contracts;
using Entities.Models;

namespace Repository
{
    internal sealed class CategoriaRepository : RepositoryBase<Categoria>, ICategoriaRepository
    {
        public CategoriaRepository(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {
        }

        public IEnumerable<Categoria> GetAllCategorias(bool trackChanges) =>
            FindAll(trackChanges)
            .OrderBy(e => e.Nombre)
            .ToList();

        public Categoria GetCategoriaById(Guid categoriaId, bool trackChanges) =>
            FindByCondition(e => e.categoriaId.Equals(categoriaId), trackChanges)
            .SingleOrDefault();

        public void CreateCategoria(Categoria categoria) => Create(categoria);

        public IEnumerable<Categoria> GetByIds(IEnumerable<Guid> ids, bool trackChanges) =>
            FindByCondition(x => ids.Contains(x.categoriaId), trackChanges);


        public void DeleteCategoria(Categoria categoria) => Delete(categoria);
    }
}

