﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace APIRestProyecto.Migrations
{
    /// <inheritdoc />
    public partial class api : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categorias",
                columns: table => new
                {
                    categoriaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nombre = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categorias", x => x.categoriaId);
                });

            migrationBuilder.CreateTable(
                name: "Stocks",
                columns: table => new
                {
                    StockId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CantidadReal = table.Column<int>(type: "int", maxLength: 60, nullable: false),
                    CantidadIdeal = table.Column<int>(type: "int", maxLength: 60, nullable: false),
                    CantidadMinima = table.Column<int>(type: "int", nullable: false),
                    CantidadAlarma = table.Column<int>(type: "int", nullable: false),
                    FechaIngreso = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Stocks", x => x.StockId);
                });

            migrationBuilder.CreateTable(
                name: "Productos",
                columns: table => new
                {
                    Productoid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nombre = table.Column<string>(type: "nvarchar(60)", maxLength: 60, nullable: false),
                    Cantidad = table.Column<int>(type: "int", maxLength: 60, nullable: false),
                    Precio = table.Column<float>(type: "real", nullable: false),
                    Estado = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Lugar = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StockId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CategoriaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Productos", x => x.Productoid);
                    table.ForeignKey(
                        name: "FK_Productos_Categorias_CategoriaId",
                        column: x => x.CategoriaId,
                        principalTable: "Categorias",
                        principalColumn: "categoriaId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Productos_Stocks_StockId",
                        column: x => x.StockId,
                        principalTable: "Stocks",
                        principalColumn: "StockId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Precios",
                columns: table => new
                {
                    PrecioId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PrecioCompra = table.Column<float>(type: "real", maxLength: 60, nullable: false),
                    PrecioVenta = table.Column<float>(type: "real", maxLength: 60, nullable: false),
                    PrecioDescuento = table.Column<float>(type: "real", nullable: false),
                    FechaDescuento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Estado = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Precios", x => x.PrecioId);
                    table.ForeignKey(
                        name: "FK_Precios_Productos_PId",
                        column: x => x.PId,
                        principalTable: "Productos",
                        principalColumn: "Productoid",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categorias",
                columns: new[] { "categoriaId", "Nombre" },
                values: new object[,]
                {
                    { new Guid("4f9a7cdb-c6dd-4c1c-8ca2-88f34c913c54"), "Portatiles" },
                    { new Guid("5af38236-256e-4ded-a81e-8010f08c51b6"), "Implementos" },
                    { new Guid("b130f449-a5f3-4e3e-a165-d73c3b73a241"), "Auriculares" }
                });

            migrationBuilder.InsertData(
                table: "Stocks",
                columns: new[] { "StockId", "CantidadAlarma", "CantidadIdeal", "CantidadMinima", "CantidadReal", "FechaIngreso" },
                values: new object[,]
                {
                    { new Guid("9fffc55a-186f-4d62-88b4-78b43b2948c1"), 5, 40, 10, 80, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(21) },
                    { new Guid("e9208668-35d6-4862-b4f6-2b3fe8f6a525"), 5, 50, 2, 150, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(24) },
                    { new Guid("f46678ca-5e2e-4b36-8d56-5eb110770bbe"), 5, 100, 30, 250, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(22) }
                });

            migrationBuilder.InsertData(
                table: "Productos",
                columns: new[] { "Productoid", "Cantidad", "CategoriaId", "Estado", "Lugar", "Nombre", "Precio", "StockId" },
                values: new object[,]
                {
                    { new Guid("03a78db6-0e2e-4d18-9001-fbccb5cc2dca"), 1, new Guid("b130f449-a5f3-4e3e-a165-d73c3b73a241"), "Activo", "Estante 1", "Audifonos inalambricos", 250000f, new Guid("f46678ca-5e2e-4b36-8d56-5eb110770bbe") },
                    { new Guid("3bbe0bbe-0379-4d32-9fd9-d74a51d319a6"), 1, new Guid("5af38236-256e-4ded-a81e-8010f08c51b6"), "Activo", "Estante 3", "Mouse inalambrico", 50000f, new Guid("9fffc55a-186f-4d62-88b4-78b43b2948c1") },
                    { new Guid("6bd9dded-9a5f-412c-9575-2110dbd9b7c6"), 1, new Guid("4f9a7cdb-c6dd-4c1c-8ca2-88f34c913c54"), "Activo", "Estante 2", "Computador Samsung 2018", 2600000f, new Guid("e9208668-35d6-4862-b4f6-2b3fe8f6a525") }
                });

            migrationBuilder.InsertData(
                table: "Precios",
                columns: new[] { "PrecioId", "Estado", "FechaDescuento", "PId", "PrecioCompra", "PrecioDescuento", "PrecioVenta" },
                values: new object[,]
                {
                    { new Guid("369ccaf1-e340-4ee9-b612-acc195dc856a"), "Inactivo", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(24), new Guid("6bd9dded-9a5f-412c-9575-2110dbd9b7c6"), 342f, 234f, 342f },
                    { new Guid("8285b178-56af-4939-aada-e35f6e067db5"), "Inactivo", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(24), new Guid("3bbe0bbe-0379-4d32-9fd9-d74a51d319a6"), 678f, 456f, 456f },
                    { new Guid("c20a3432-81eb-48c2-a25e-6574cd445cbb"), "Inactivo", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(24), new Guid("03a78db6-0e2e-4d18-9001-fbccb5cc2dca"), 34f, 45f, 45f }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Precios_PId",
                table: "Precios",
                column: "PId");

            migrationBuilder.CreateIndex(
                name: "IX_Productos_CategoriaId",
                table: "Productos",
                column: "CategoriaId");

            migrationBuilder.CreateIndex(
                name: "IX_Productos_StockId",
                table: "Productos",
                column: "StockId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Precios");

            migrationBuilder.DropTable(
                name: "Productos");

            migrationBuilder.DropTable(
                name: "Categorias");

            migrationBuilder.DropTable(
                name: "Stocks");
        }
    }
}
