﻿ using Entities.Models;
using Shared.DataTransferObjects;
using AutoMapper;

namespace APIRestProyecto
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //Stock
            CreateMap<Stock, StockDTO>()
            .ForMember(DTO => DTO.stockId, opt => opt.MapFrom(src=> src.stockId));

            CreateMap<StockForCreationDTO, Stock>();
            CreateMap<StockForUpdateDTO, Stock>();

            //Producto
            CreateMap<Producto, ProductoDTO>();
            CreateMap<ProductoForCreationDTO, Producto>();
            CreateMap<ProductoForUpdateDTO, Producto>();

            //Categoria
            CreateMap<Categoria, CategoriaDTO>();
            CreateMap<CategoriaForCreationDTO, Categoria>(); 
            CreateMap<CategoriaForUpdateDTO, Categoria>();

            //Precio
            CreateMap<Precio, PrecioDTO>();
            CreateMap<PrecioForCreationDTO, Precio>();
            CreateMap<PrecioForUpdateDTO, Precio>();
        }
    }
}
