﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObjects;
namespace Service
{
    internal sealed class PrecioService : IPrecioService
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public PrecioService(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }

        public IEnumerable<PrecioDTO> GetAllPrecios(Guid PId, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductById(PId, trackChanges);
            if (producto is null)
                throw new ProductoNotFoundException(PId);
            var preciosFromDb = _repository.Precio.GetAllPrecios(PId, trackChanges);
            var preciosDTO = _mapper.Map<IEnumerable<PrecioDTO>>(preciosFromDb);
            return preciosDTO;
        }//

        public PrecioDTO GetPrecioById(Guid PId, Guid PrecioId, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductById(PId, trackChanges);
            if (producto is null)
                throw new ProductoNotFoundException(PId);

            var precioDb = _repository.Precio.GetPrecioById(PId, PrecioId, trackChanges);
            if (precioDb is null)
                throw new PrecioNotFoundException(PrecioId);


            var precio = _mapper.Map<PrecioDTO>(precioDb);
            return precio;
        }
        //
        public PrecioDTO CreatePrecioForProducto(Guid PId, PrecioForCreationDTO precioForCreation, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductById(PId, trackChanges);
            if (producto is null)
                throw new ProductoNotFoundException(PId);

            var precioEntity = _mapper.Map<Precio>(precioForCreation);
            _repository.Precio.CreatePrecioForProducto(PId, precioEntity);
            _repository.Save();

            var precioToReturn = _mapper.Map<PrecioDTO>(precioEntity);
            return precioToReturn;
        }

        public void DeletePrecioForProducto(Guid PId, Guid PrecioId, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductById(PId, trackChanges);
            if (producto is null)
            {
                throw new ProductoNotFoundException(PId);
            }

            var precioForProducto = _repository.Precio.GetPrecioById(PId, PrecioId, trackChanges);
            if (precioForProducto is null)
            {
                throw new PrecioNotFoundException(PrecioId);
            }

            _repository.Precio.DeletePrecio(precioForProducto);
            _repository.Save();

        }

        public void UpdatePrecioForProducto(Guid PId, Guid PrecioId, PrecioForUpdateDTO precioForUpdate, bool compTrackChanges, bool empTrackChanches)
        {
            var producto = _repository.Producto.GetProductById(PId, compTrackChanges);
            if (producto is null)
            {
                throw new ProductoNotFoundException(PId);
            }

            var precioEntity = _repository.Precio.GetPrecioById(PId, PrecioId, empTrackChanches);
            if (precioEntity is null)
            {
                throw new PrecioNotFoundException(PrecioId);
            }
            _mapper.Map(precioForUpdate, precioEntity);
            _repository.Save();
        }
    }
}

