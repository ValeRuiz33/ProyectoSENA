﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObjects;

namespace Service
{
    internal sealed class ProductoService : IProductoService
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public ProductoService(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }
        //Producto
        public IEnumerable<ProductoDTO> GetAllProducts(bool trackChanges)
        {
            var productos = _repository.Producto.GetAllProducts(trackChanges);
            var productosDTO = _mapper.Map<IEnumerable<ProductoDTO>>(productos);
            return productosDTO;
        }

        public ProductoDTO GetProductById(Guid PId, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductById(PId, trackChanges);
            //Check if the company is null
            if (producto is null)
                throw new ProductoNotFoundException(PId);

            var productoDTO = _mapper.Map<ProductoDTO>(producto);

            return productoDTO;
        }
        //

        public ProductoDTO CreateProduct(ProductoForCreationDTO producto)
        {
            var productoEntity = _mapper.Map<Producto>(producto);

            _repository.Producto.CreateProduct(productoEntity);
            _repository.Save();

            var productoToReturn = _mapper.Map<ProductoDTO>(productoEntity);

            return productoToReturn;
        }

        public IEnumerable<ProductoDTO> GetByIds(IEnumerable<Guid> ids, bool trackChanges)
        {
            if (ids is null)
                throw new IdParametersBadRequestException();

            var productoEntities = _repository.Producto.GetByIds(ids, trackChanges);
            if (ids.Count() != productoEntities.Count())
                throw new CollectionByIdsBadRequestException();

            var productosToReturn = _mapper.Map<IEnumerable<ProductoDTO>>(productoEntities);

            return productosToReturn;
        }

        public (IEnumerable<ProductoDTO> productos, string ids) CreateProductoCollection
            (IEnumerable<ProductoForCreationDTO> productoCollection)
        {
            if (productoCollection is null)
                throw new ProductoCollectionBadRequest();

            var productoEntities = _mapper.Map<IEnumerable<Producto>>(productoCollection);
            foreach (var producto in productoEntities)
            {
                _repository.Producto.CreateProduct(producto);
            }

            _repository.Save();

            var productoCollectionToReturn = _mapper.Map<IEnumerable<ProductoDTO>>(productoEntities);
            var ids = string.Join(",", productoCollectionToReturn.Select(c => c.PId));

            return (productos: productoCollectionToReturn, ids: ids);
        }

        public void DeleteProducto(Guid PId, bool trackChanges)
        {
            var producto = _repository.Producto.GetProductById(PId, trackChanges);
            if (producto == null)
            {
                throw new ProductoNotFoundException(PId);
            }

            _repository.Producto.DeleteProducto(producto);
            _repository.Save();

        }

        public void UpdateProducto(Guid PId, ProductoForUpdateDTO productoForUpdate, bool trackChanches)
        {
            var productoEntity = _repository.Producto.GetProductById(PId, trackChanches);
            if (productoEntity == null)
            {
                throw new ProductoNotFoundException(PId);
            }
            _mapper.Map(productoForUpdate, productoEntity);
            _repository.Save();
        }
            //stock
            public IEnumerable<ProductoDTO> GetAllProductos(Guid stockId,bool trackChanges)
        {
            var stock = _repository.Stock.GetStockById(stockId, trackChanges);
            if (stock is null) 
                throw new StockNotFoundException(stockId);
            var productosFromDb= _repository.Producto.GetAllProductos(stockId, trackChanges);
            var productosDTO = _mapper.Map<IEnumerable<ProductoDTO>>(productosFromDb); 
            return productosDTO;
        }

        public ProductoDTO GetProductoById(Guid stockId, Guid PId, bool trackChanges)
        {
            var stock = _repository.Stock.GetStockById(stockId, trackChanges);
            if (stock is null)
                throw new StockNotFoundException(stockId);

            var productoDb = _repository.Producto.GetProductoById(stockId, PId, trackChanges);
            if(productoDb is null)
                throw new ProductoNotFoundException(PId);


            var producto = _mapper.Map<ProductoDTO>(productoDb);
            return producto;
        }

        public ProductoDTO CreateProductoForStock(Guid stockId, ProductoForCreationDTO productoForCreation, bool trackChanges)
        {
            var stock = _repository.Stock.GetStockById(stockId, trackChanges); 
            if (stock is null)
                throw new StockNotFoundException(stockId);

            var productoEntity = _mapper.Map<Producto>(productoForCreation);
            _repository.Producto.CreateProductoForStock(stockId, productoEntity);
            _repository.Save();

            var productoToReturn = _mapper.Map<ProductoDTO>(productoEntity);
            return productoToReturn;
        }

        public void DeleteProductoForStock(Guid stockId, Guid PId, bool trackChanges)
        {
            var stock = _repository.Stock.GetStockById(stockId, trackChanges);
            if (stock is null)
            {
                throw new StockNotFoundException(stockId);
            }

            var productoForStock = _repository.Producto.GetProductoById(stockId, PId, trackChanges);
            if (productoForStock is null)
            {
                throw new ProductoNotFoundException(PId);
            }

            _repository.Producto.DeleteProducto(productoForStock);
            _repository.Save();

        }

        public void UpdateProductoForStock(Guid stockId, Guid PId, ProductoForUpdateDTO productoForUpdate, bool compTrackChanges, bool empTrackChanches)
        {
            var stock = _repository.Stock.GetStockById(stockId, compTrackChanges);
            if (stock is null)
            {
                throw new StockNotFoundException(stockId);
            }

            var productoEntity = _repository.Producto.GetProductoById(stockId, PId, empTrackChanches);
            if (productoEntity is null)
            {
                throw new ProductoNotFoundException(PId);
            }
            _mapper.Map(productoForUpdate, productoEntity);
            _repository.Save();
        }

        //Categoria
        public IEnumerable<ProductoDTO> GetAllProductosC(Guid categoriaId, bool trackChanges)
        {
            var categoria = _repository.Categoria.GetCategoriaById(categoriaId, trackChanges);
            if (categoria is null)
                throw new CategoriaNotFoundException(categoriaId);

            var productosFromDb = _repository.Producto.GetAllProductosC(categoriaId, trackChanges);
            var productosDTO = _mapper.Map<IEnumerable<ProductoDTO>>(productosFromDb);
            return productosDTO;
        }

        public ProductoDTO GetProductoByIdC(Guid categoriaId, Guid PId, bool trackChanges)
        {
            var categoria = _repository.Categoria.GetCategoriaById(categoriaId, trackChanges);
            if (categoria is null)
                throw new CategoriaNotFoundException(categoriaId);

            var productoDb = _repository.Producto.GetProductoByIdC(categoriaId, PId, trackChanges);
            if (productoDb is null)
                throw new ProductoNotFoundException(PId);


            var producto = _mapper.Map<ProductoDTO>(productoDb);
            return producto;
        }

        public ProductoDTO CreateProductoForCategoria(Guid categoriaId, ProductoForCreationDTO productoForCreation, bool trackChanges)
        {
            var categoria = _repository.Categoria.GetCategoriaById(categoriaId, trackChanges);
            if (categoria is null)
                throw new CategoriaNotFoundException(categoriaId);

            var productoEntity = _mapper.Map<Producto>(productoForCreation);
            _repository.Producto.CreateProductoForStock(categoriaId, productoEntity);
            _repository.Save();

            //var productoEntity = _mapper.Map<Producto>(producto);
            //_repository.Producto.CreateProducto(productoEntity);
            //_repository.Save();
            var productoToReturn = _mapper.Map<ProductoDTO>(productoEntity);
            return productoToReturn;
        }

        public void DeleteProductoForCategoria(Guid categoriaId, Guid PId, bool trackChanges)
        {
            var categoria = _repository.Categoria.GetCategoriaById(categoriaId, trackChanges);
            if (categoria is null)
            {
                throw new CategoriaNotFoundException(categoriaId);
            }

            var productoForCategoria = _repository.Producto.GetProductoById(categoriaId, PId, trackChanges);
            if (productoForCategoria is null)
            {
                throw new ProductoNotFoundException(PId);
            }

            _repository.Producto.DeleteProducto(productoForCategoria);
            _repository.Save();

        }

        public void UpdateProductoForCategoria(Guid categoriaId, Guid PId, ProductoForUpdateDTO productoForUpdate, bool compTrackChanges, bool empTrackChanches)
        {
            var categoria = _repository.Categoria.GetCategoriaById(categoriaId, compTrackChanges);
            if (categoria is null)
            {
                throw new CategoriaNotFoundException(categoriaId);
            }

            var productoEntity = _repository.Producto.GetProductoById(categoriaId, PId, empTrackChanches);
            if (productoEntity is null)
            {
                throw new ProductoNotFoundException(PId);
            }
            _mapper.Map(productoForUpdate, productoEntity);
            _repository.Save();
        }
    }
}

            

            
           
