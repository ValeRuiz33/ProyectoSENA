﻿using AutoMapper;
using Contracts;
using Entities.Exceptions;
using Entities.Models;
using Service.Contracts;
using Shared.DataTransferObjects;

namespace Service
{
    internal sealed class CategoriaService : ICategoriaService
    {
        private readonly IRepositoryManager _repository;
        private readonly ILoggerManager _logger;
        private readonly IMapper _mapper;

        public CategoriaService(IRepositoryManager repository, ILoggerManager logger, IMapper mapper)
        {
            _repository = repository;
            _logger = logger;
            _mapper = mapper;
        }
        public IEnumerable<CategoriaDTO> GetAllCategorias(bool trackChanges)
        {
            var categorias = _repository.Categoria.GetAllCategorias(trackChanges);
            var categoriaDTO = _mapper.Map<IEnumerable<CategoriaDTO>>(categorias);
            return categoriaDTO;
        }//

        public CategoriaDTO GetCategoriaById(Guid CategoriaId, bool trackChanges)
        {
            var categoria = _repository.Categoria.GetCategoriaById(CategoriaId, trackChanges);
            if (categoria == null)
            {
                throw new CategoriaNotFoundException(CategoriaId);
            }
            var categoriaDTO = _mapper.Map<CategoriaDTO>(categoria);
            return categoriaDTO;
        }
        public CategoriaDTO CreateCategoria(CategoriaForCreationDTO categoria)
        {
            var categoriaEntity = _mapper.Map<Categoria>(categoria);

            _repository.Categoria.CreateCategoria(categoriaEntity);
            _repository.Save();

            var categoriaToReturn = _mapper.Map<CategoriaDTO>(categoriaEntity);

            return categoriaToReturn;
        }

        public IEnumerable<CategoriaDTO> GetByIds(IEnumerable<Guid> ids, bool trackChanges)
        {
            if (ids is null)
                throw new IdParametersBadRequestException();

            var categoriaEntities = _repository.Categoria.GetByIds(ids, trackChanges);
            if (ids.Count() != categoriaEntities.Count())
                throw new CollectionByIdsBadRequestException();

            var categoriasToReturn = _mapper.Map<IEnumerable<CategoriaDTO>>(categoriaEntities);

            return categoriasToReturn;
        }

        public (IEnumerable<CategoriaDTO> categorias, string ids) CreateCategoriaCollection
            (IEnumerable<CategoriaForCreationDTO> categoriaCollection)
        {
            if (categoriaCollection is null)
                throw new CategoriaCollectionBadRequest();

            var categoriaEntities = _mapper.Map<IEnumerable<Categoria>>(categoriaCollection);
            foreach (var categoria in categoriaEntities)
            {
                _repository.Categoria.CreateCategoria(categoria);
            }

            _repository.Save();

            var categoriaCollectionToReturn = _mapper.Map<IEnumerable<CategoriaDTO>>(categoriaEntities);
            var ids = string.Join(",", categoriaCollectionToReturn.Select(c => c.CategoriaId));

            return (categorias: categoriaCollectionToReturn, ids: ids);
        }

        public void DeleteCategoria(Guid CategoriaId, bool trackChanges)
        {
            var categoria = _repository.Categoria.GetCategoriaById(CategoriaId, trackChanges);
            if (categoria == null)
            {
                throw new CategoriaNotFoundException(CategoriaId);
            }

            _repository.Categoria.DeleteCategoria(categoria);
            _repository.Save();

        }

        public void UpdateCategoria(Guid CategoriaId, CategoriaForUpdateDTO categoriaForUpdate, bool trackChanches)
        {
            var categoriaEntity = _repository.Categoria.GetCategoriaById(CategoriaId, trackChanches);
            if (categoriaEntity is null)
            {
                throw new CategoriaNotFoundException(CategoriaId);
            }
            _mapper.Map(categoriaForUpdate, categoriaEntity);
            _repository.Save();
        }
    }
}
