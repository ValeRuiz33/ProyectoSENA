﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contracts
{
    public interface ICategoriaRepository
    {
        IEnumerable<Categoria> GetAllCategorias(bool trackChanges);
        Categoria GetCategoriaById(Guid CategoriaId, bool trackChanges);
        void CreateCategoria(Categoria categoria);
        IEnumerable<Categoria> GetByIds(IEnumerable<Guid> ids, bool trackChanges);
        void DeleteCategoria(Categoria categoria);
    }
}
