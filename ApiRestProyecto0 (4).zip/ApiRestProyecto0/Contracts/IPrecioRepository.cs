﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Contracts
{
    public interface IPrecioRepository
    {
        IEnumerable<Precio> GetAllPrecios(Guid PId, bool trackChanges);
        Precio GetPrecioById(Guid PId, Guid PrecioId, bool trackChanges);
        void CreatePrecioForProducto(Guid PId, Precio precio);
        void DeletePrecio(Precio precio);
    }
}
