﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities.Models;


namespace Contracts
{
    public interface IProductoRepository
    {
        //Producto
        IEnumerable<Producto> GetAllProducts(bool trackChanges);
        Producto GetProductById(Guid PId, bool trackChanges);
        void CreateProduct(Producto producto);
        IEnumerable<Producto> GetByIds(IEnumerable<Guid> ids, bool trackChanges);
        void DeleteProducto(Producto producto);

        //stock
        IEnumerable<Producto> GetAllProductos(Guid stockId, bool trackChanges);
        Producto GetProductoById(Guid stockId, Guid PId, bool trackChanges);
        void CreateProductoForStock(Guid stockId, Producto producto);



        //Categoria

        IEnumerable<Producto> GetAllProductosC(Guid categoriaId, bool trackChanges);
        Producto GetProductoByIdC(Guid categoriaId, Guid PId, bool trackChanges);
        void CreateProductoForCategoria(Guid categoriaId, Producto producto);


        //Precio
        //IEnumerable<Producto> GetAllProductosP(Guid PrecioId, bool trackChanges);
        //Producto GetProductoByIdP(Guid PId, Guid PrecioId, bool trackChanges);
        //void DeleteProductos(Stock producto);
    }
}
